package com.gl.cryptoAuthenticationApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptoAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptoAuthenticationApplication.class, args);
	}

}
